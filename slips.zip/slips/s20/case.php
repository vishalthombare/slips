<?php
	$name=$_POST['name'];
	echo "<b>Upper Case :</b>".strtoupper($name)."<br>";
	echo "<b>First Character Upper Case:</b>".ucwords($name);
?>

