create table teacher(tno serial primary key, name text, subject text, research_area text);

insert into teacher(name,subject,research_area) values('Ram Kale','C++','Programming Practices'),('Seeta Gore','Operating System','Multicore Programming'),('Krishna Yadav','PHP','Web Techniques'),('Radha Kumari','TCS','Automata Theory');

