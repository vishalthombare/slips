create table Dept(d_no serial primary key, dname text, location text);
create table Emp(e_no serial primary key, ename text, address text, phone text, salary float,d_no int references Dept(d_no));



